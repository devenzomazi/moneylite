<?php
// Conectar ao banco
include('../conexao.php');

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Receber dados
$descricao = $_POST['descricao'];
$categoria = $_POST['categoria'];
$valor = $_POST['valor'];
$data_cadastro = $_POST['data_cadastro'];

// Inserir no banco
$sql = "INSERT INTO ganhos (descricao, categoria, valor, data_cadastro) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssds", $descricao, $categoria, $valor, $data_cadastro);

if ($stmt->execute()) {
    echo "<script>alert('Ganho cadastrado com sucesso!'); window.location.href='ganhos.php';</script>";
} else {
    echo "<script>alert('Erro ao cadastrar ganho.'); window.location.href='ganhos.php';</script>";
}

$stmt->close();
$conn->close();
?>
