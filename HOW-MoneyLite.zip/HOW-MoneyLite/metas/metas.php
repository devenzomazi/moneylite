<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Metas - MoneyLite</title>
    <link rel="stylesheet" href="../dashboard/dashboard.css">
    <link rel="stylesheet" href="../geral.css">
    <link rel="stylesheet" href="metas.css">
</head>
<body>
    <div class="navbar">
        <div>
            <div class="top">
                <img src="../img/logo.png" alt="">
                <div>
                    <h2>Enzo Maziviero</h2>
                    <p>22 anos</p>
                    <p>Especialista em Gastos</p>
                </div>
            </div>
            <div class="options-menu">
                <div class="line"></div>
                <a href="../dashboard/dashboard.php">DashBoards</a>
                <a href="../ganhos/ganhos.php">Ganhos</a>
                <a href="../despesa/despesa.php">Despesas</a>
                <a href="metas.php">Metas</a>
            </div>
        </div>
        <div class="line"></div>
        <div class="bot">
            <a href="../index.php">Sair</a>
        </div>
    </div>

    <div class="main-dash">
        <div class="top">
            <h1>MoneyLite</h1>
        </div>
        <div class="main-metas">
            <div class="top-metas">
                <h1>Controle de Metas</h1>
            </div>

            <form method="POST" action="metas.php">
                <div class="filtros-content">
                    <div class="filtros-metas">
                        <!-- campos de filtro -->
                        <div class="card-filter">
                            <label for="">Código Meta:</label>
                            <input type="text" name="cod-meta">
                        </div>

                        <div class="card-filter">
                            <label for="">Descrição Meta:</label>
                            <input type="text" name="desc-meta">
                        </div>

                        <div class="card-filter">
                            <label for="">Data Limite:</label>
                            <input type="date" name="data-limite">
                        </div>

                        <div class="pesquisa">
                            <button type="submit">Pesquisar</button>
                        </div>
                    </div>
                </div>
             </form>

            <?php
                    // Excluir uma meta se houver parâmetro 'excluir' na URL
                    if (isset($_GET['excluir'])) {
                        $idExcluir = intval($_GET['excluir']); // Protege para aceitar só número

                        // Conectar ao banco
                        $conn = new mysqli("localhost", "root", "", "ua10");

                        if ($conn->connect_error) {
                            die("Falha na conexão: " . $conn->connect_error);
                        }

                        // Preparar exclusão segura
                        $sqlExcluir = "DELETE FROM metas WHERE id_meta = ?";
                        $stmt = $conn->prepare($sqlExcluir);
                        $stmt->bind_param("i", $idExcluir);

                        if ($stmt->execute()) {
                            echo "<script>alert('Meta excluída com sucesso!'); window.location.href='metas.php';</script>";
                        } else {
                            echo "<script>alert('Erro ao excluir a meta.'); window.location.href='metas.php';</script>";
                        }

                        $stmt->close();
                        $conn->close();
                        exit(); // Interrompe para não listar novamente enquanto exclui
                    }
            ?>

            <div class="lista-metas">
                <table border="1">
                    <thead>
                        <tr>
                            <th>Código Meta</th>
                            <th>Descrição Meta</th>
                            <th>Valor Objetivo</th>
                            <th>Valor Atual</th>
                            <th>Progresso</th>
                            <th>Data Limite</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Conectar ao banco
                        $conn = new mysqli("localhost", "root", "", "ua10");

                        if ($conn->connect_error) {
                            die("Falha na conexão: " . $conn->connect_error);
                        }

                        // Receber filtros
                        $codMeta = $_POST['cod-meta'] ?? '';
                        $descMeta = $_POST['desc-meta'] ?? '';
                        $dataLimite = $_POST['data-limite'] ?? '';

                        // Montar consulta base
                        $sql = "SELECT * FROM metas WHERE 1=1";

                        // Adicionar filtros dinamicamente
                        if (!empty($codMeta)) {
                            $sql .= " AND id_meta = '$codMeta'";
                        }
                        if (!empty($descMeta)) {
                            $sql .= " AND descricao LIKE '%$descMeta%'";
                        }
                        if (!empty($dataLimite)) {
                            $sql .= " AND data_limite = '$dataLimite'";
                        }

                        // Executar consulta
                        $result = $conn->query($sql);

                        // Listar resultados
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                // Calcular progresso (%)
                                $progresso = 0;
                                if ($row['valor_objetivo'] > 0) {
                                    $progresso = ($row['valor_atual'] / $row['valor_objetivo']) * 100;
                                }

                                echo "<tr>";
                                echo "<td>".$row['id_meta']."</td>";
                                echo "<td>".$row['descricao']."</td>";
                                echo "<td>R$ ".number_format($row['valor_objetivo'], 2, ',', '.')."</td>";
                                echo "<td>R$ ".number_format($row['valor_atual'], 2, ',', '.')."</td>";
                                echo "<td>".round($progresso)."%</td>";
                                echo "<td>".date('d/m/Y', strtotime($row['data_limite']))."</td>";
                                echo "<td>
                                        <a href='alterar-meta.php?id=".$row['id_meta']."'>Alterar</a> |
                                        <a href='metas.php?excluir=".$row['id_meta']."' onclick=\"return confirm('Tem certeza que deseja excluir esta meta?')\">Excluir</a>
                                    </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7'>Nenhuma meta encontrada.</td></tr>";
                        }

                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </div>
            </div>
            <div class="inclusao">
                <button onclick="window.location.href='incluir-meta.php'">Incluir Nova Meta</button>
            </div>
    </div>
</body>
</html>
