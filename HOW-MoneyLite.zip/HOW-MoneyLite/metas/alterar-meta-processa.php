<?php
// Conectar ao banco
$conn = new mysqli("localhost", "root", "", "ua10");

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Receber os dados
$id = intval($_POST['id']);
$descricao = $_POST['descricao'];
$valor_objetivo = $_POST['valor_objetivo'];
$valor_atual = $_POST['valor_atual'];
$data_limite = $_POST['data_limite'];

// Atualizar a meta
$sql = "UPDATE metas SET descricao = ?, valor_objetivo = ?, valor_atual = ?, data_limite = ? WHERE id_meta = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sddsi", $descricao, $valor_objetivo, $valor_atual, $data_limite, $id);

if ($stmt->execute()) {
    echo "<script>alert('Meta alterada com sucesso!'); window.location.href='metas.php';</script>";
} else {
    echo "<script>alert('Erro ao alterar a meta.'); window.location.href='metas.php';</script>";
}

$stmt->close();
$conn->close();
?>
