<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DashBoard - MoneyLite</title>
    <link rel="stylesheet" href="dashboard.css">
    <link rel="stylesheet" href="../geral.css">
</head>
<body>
    <div class="navbar">
        <div>
            <div class="top">
                <img src="../img/logo.png" alt="">
                <div>
                <h2>Enzo Maziviero</h2>
                <p>22 anos</p>
                <p>Especialista em Gastos</p>
                </div>
            </div>
            
            <div class="options-menu">
                <div class="line"></div>
                <a href="dashboard.php">DashBoards</a>
                <a href="../ganhos/ganhos.php">Ganhos</a>
                <a href="../despesa/despesa.php">Despesas</a>
                <a href="../metas/metas.php">Metas</a>
            </div>
        </div>
        <div class="line"></div>
        <div class="bot">
            <a href="../index.php">Sair</a>
        </div>
    </div>
    <?php
            // Conectar ao banco
            $conn = new mysqli("localhost", "root", "", "ua10");

            if ($conn->connect_error) {
                die("Falha na conexão: " . $conn->connect_error);
            }

            // Buscar soma dos ganhos
            $resultGanhos = $conn->query("SELECT SUM(valor) AS total_ganhos FROM ganhos");
            $ganhos = $resultGanhos->fetch_assoc()['total_ganhos'] ?? 0;

            // Buscar soma das despesas
            $resultDespesas = $conn->query("SELECT SUM(valor) AS total_despesas FROM despesas");
            $despesas = $resultDespesas->fetch_assoc()['total_despesas'] ?? 0;

            // Calcular saldo
            $saldoAtual = $ganhos - $despesas;

            $conn->close();
            ?>
    <div class="main-dash">
        <div class="top">
            <h1>MoneyLite</h1>
        </div>
        <?php
            $corSaldo = ($saldoAtual >= 0) ? '#2e8b57' : '#ff4500'; // verde ou vermelho
        ?>
        
        <div class="saldo">
            <h2>Saldo Atual</h2>
            <h1>R$ <?php echo number_format($saldoAtual, 2, ',', '.'); ?></h1>
        </div>

        <div class="cards">
            <div class="gasto">
                <h2>Ultimas Despesas</h2>
                <?php include 'ultimos-gastos.php'; ?>
            </div>
            <div class="ganho">
                <h2>Ultimos Ganhos</h2>
                <?php include 'ultimos-ganhos.php'; ?>
            </div>
            <div class="meta">
                <h2>Metas</h2>
                <?php
                    // Conectar ao banco
                    $conn = new mysqli("localhost", "root", "", "ua10");

                    if ($conn->connect_error) {
                        die("Falha na conexão: " . $conn->connect_error);
                    }

                    // Buscar últimas 4 metas
                    $result = $conn->query("SELECT descricao, valor_objetivo, valor_atual, data_limite FROM metas ORDER BY id_meta DESC LIMIT 4");

                    echo "<ul class='lista-metas'>";
                    while ($meta = $result->fetch_assoc()) {
                        // Calcular progresso
                        $progresso = 0;
                        if ($meta['valor_objetivo'] > 0) {
                            $progresso = ($meta['valor_atual'] / $meta['valor_objetivo']) * 100;
                        }
                        echo "<li class='meta-ultima'>";
                        echo "🏆 ".$meta['descricao']." - ".round($progresso)."% (".date('d/m/Y', strtotime($meta['data_limite'])).")";
                        echo "</li>";
                    }
                    echo "</ul>";

                    $conn->close();
                ?>
            </div>
        </div>
    </div>
</body>
</html>