<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ganhos- MoneyLite</title>
    <link rel="stylesheet" href="../dashboard/dashboard.css">
    <link rel="stylesheet" href="../geral.css">
    <link rel="stylesheet" href="ganhos.css">
</head>
<body>
    <div class="navbar">
        <div>
            <div class="options-menu">
                <div class="line"></div>
                <a href="../dashboard/dashboard.php">DashBoards</a>
                <a href="../ganhos/ganhos.php">Ganhos</a>
                <a href="../despesa/despesa.php">Despesas</a>
                <a href="../metas/metas.php">Metas</a>
            </div>
        </div>
        <div class="line"></div>
        <div class="bot">
            <a href="../index.php">Sair</a>
        </div>
    </div>
    <div class="main-dash">
        <div class="top">
            <h1>MoneyLite</h1>
        </div>
        <div class="main-ganhos">
            <div class="top-ganhos">
                <h1>Controle de Ganhos</h1>
            </div>
            <div class="filtros-content">
                <form method="POST" action="ganhos.php">
                <div class="filtros-ganhos">
                    <div class="card-filter">
                        <label for="cod-ganho">Código Ganho:</label>
                        <input type="text" name="cod-ganho" id="cod-ganho">
                    </div>

                    <div class="card-filter"> 
                        <label for="desc-ganho">Descrição Ganho:</label>
                        <input type="text" name="desc-ganho" id="desc-ganho">
                    </div>

                    <div class="card-filter"> 
                        <label for="valor-ganho">Ranges Valores Ganho:</label>
                        <select name="valor-ganho" id="valor-ganho">
                            <option value="">Todos</option>
                            <option value="abaixo_100">abaixo de 100</option>
                            <option value="entre_100_200">entre 100 e 200</option>
                            <option value="entre_200_500">entre 200 e 500</option>
                            <option value="acima_500">acima de 500</option>
                        </select>
                    </div>  

                    <div class="card-filter"> 
                        <label for="data-ganho">Dt Cadastro Ganho:</label>
                        <input type="date" name="data-ganho" id="data-ganho">
                    </div>  

                    <div class="pesquisa">
                        <button type="submit">Pesquisar</button>
                    </div>
                </div>
                </form>
            </div>
            <div class="lista-ganhos">
                <table border="1">
                    <thead>
                        <tr>
                            <th>Código Ganho</th>
                            <th>Descrição Ganho:</th>
                            <th>Categoria</th>
                            <th>Valor Ganho</th>
                            <th>Data Cadastro</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Se o botão excluir foi clicado
                        if (isset($_GET['excluir'])) {
                            $idExcluir = intval($_GET['excluir']); // segura para evitar SQL Injection

                            // Conectar ao banco
                            // Conectar ao banco
                             include('../conexao.php');

                            // Excluir o registro
                            $sqlExcluir = "DELETE FROM ganhos WHERE id_ganho = ?";
                            $stmt = $conn->prepare($sqlExcluir);
                            $stmt->bind_param("i", $idExcluir);

                            if ($stmt->execute()) {
                                echo "<script>alert('Ganho excluído com sucesso!'); window.location.href='ganhos.php';</script>";
                            } else {
                                echo "<script>alert('Erro ao excluir ganho.'); window.location.href='ganhos.php';</script>";
                            }

                            $stmt->close();
                            $conn->close();
                            exit(); // Termina aqui para não executar o resto da página
                        }
                        ?>
                    <?php
                    // Conectar ao banco
                    include('../conexao.php');

                    // Recebe filtros
                    $codGanho = $_POST['cod-ganho'] ?? '';
                    $descGanho = $_POST['desc-ganho'] ?? '';
                    $valorGanho = $_POST['valor-ganho'] ?? '';
                    $dataGanho = $_POST['data-ganho'] ?? '';

                    // Monta a consulta
                    $sql = "SELECT * FROM ganhos WHERE 1=1";

                    if (!empty($codGanho)) {
                        $sql .= " AND id_ganho = '$codGanho'";
                    }
                    if (!empty($descGanho)) {
                        $sql .= " AND descricao LIKE '%$descGanho%'";
                    }
                    if (!empty($valorGanho)) {
                        if ($valorGanho == "abaixo_100") {
                            $sql .= " AND valor < 100";
                        } elseif ($valorGanho == "entre_100_200") {
                            $sql .= " AND valor BETWEEN 100 AND 200";
                        } elseif ($valorGanho == "entre_200_500") {
                            $sql .= " AND valor BETWEEN 200 AND 500";
                        } elseif ($valorGanho == "acima_500") {
                            $sql .= " AND valor > 500";
                        }
                    }
                    if (!empty($dataGanho)) {
                        $sql .= " AND DATE(data_cadastro) = '$dataGanho'";
                    }

                    $result = $conn->query($sql);

                    // Monta as linhas
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>".$row['id_ganho']."</td>";
                            echo "<td>".$row['descricao']."</td>";
                            echo "<td>".$row['categoria']."</td>";
                            echo "<td>R$ ".number_format($row['valor'], 2, ',', '.')."</td>";
                            echo "<td>".date('d/m/Y', strtotime($row['data_cadastro']))."</td>";
                            echo "<td>
                                    <a href='alterar-ganho.php?id=".$row['id_ganho']."'>Alterar</a> |
                                    <a href='ganhos.php?excluir=".$row['id_ganho']."' onclick=\"return confirm('Tem certeza que deseja excluir?')\">Excluir</a>
                                  </td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6'>Nenhum ganho encontrado.</td></tr>";
                    }                    
                    

                    $conn->close();
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="inclusao">
        <button onclick="window.location.href='incluir-ganho.php'">Incluir Novo Ganho</button>
        </div>
        </div>
    </div>
</body>
</html>