<?php

// Conectar ao banco
include('../conexao.php');

// Receber dados
$id = intval($_POST['id']);
$descricao = $_POST['descricao'];
$categoria = $_POST['categoria'];
$valor = $_POST['valor'];
$data_cadastro = $_POST['data_cadastro'];

// Atualizar no banco
$sql = "UPDATE despesas SET descricao=?, categoria=?, valor=?, data_cadastro=? WHERE id_despesa=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssdsi", $descricao, $categoria, $valor, $data_cadastro, $id);

if ($stmt->execute()) {
    echo "<script>alert('Despesa alterada com sucesso!'); window.location.href='despesa.php';</script>";
} else {
    echo "<script>alert('Erro ao alterar despesa.'); window.location.href='despesa.php';</script>";
}

$stmt->close();
$conn->close();
?>
