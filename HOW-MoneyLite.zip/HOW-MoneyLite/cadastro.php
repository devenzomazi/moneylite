<?php
// 1. Conexão com o banco de dados
$servidor = "localhost"; // ou IP
$usuario = "root";       // usuário do banco
$senha = "";             // senha do banco
$banco = "ua10";    // nome do seu banco

$conn = new mysqli($servidor, $usuario, $senha, $banco);

// Verificar conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// 2. Receber os dados do formulário
$login = $_POST['login'];
$senha = $_POST['senha'];

// 3. Inserir no banco
$sql = "INSERT INTO usuarios (nome_user, senha) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $login, $senha);

if ($stmt->execute()) {
    // Sucesso no cadastro
    echo "<script>alert('Conta criada com sucesso!'); window.location.href='index.php';</script>";
} else {
    // Erro ao cadastrar
    echo "<script>alert('Erro ao criar conta: " . $conn->error . "'); window.location.href='cadastro.php';</script>";
}

$stmt->close();
$conn->close();
?>
