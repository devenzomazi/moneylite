<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incluir Nova Meta - MoneyLite</title>
</head>
<body>
    <h1>Incluir Nova Meta</h1>

    <form method="POST" action="incluir-meta-processa.php">
        <label for="descricao">Descrição da Meta:</label><br>
        <input type="text" name="descricao" id="descricao" required><br><br>

        <label for="valor_objetivo">Valor Objetivo:</label><br>
        <input type="number" step="0.01" name="valor_objetivo" id="valor_objetivo" required><br><br>

        <label for="data_limite">Data Limite:</label><br>
        <input type="date" name="data_limite" id="data_limite" required><br><br>

        <button type="submit">Salvar Nova Meta</button>
        <button type="button" onclick="window.location.href='metas.php'">Cancelar</button>
    </form>
</body>
</html>
