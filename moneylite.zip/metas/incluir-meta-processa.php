<?php
// Conectar ao banco
include('../conexao.php');

// Receber os dados
$descricao = $_POST['descricao'];
$valor_objetivo = $_POST['valor_objetivo'];
$data_limite = $_POST['data_limite'];

// Inserir no banco
$sql = "INSERT INTO metas (descricao, valor_objetivo, valor_atual, data_limite) VALUES (?, ?, 0, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sds", $descricao, $valor_objetivo, $data_limite);

if ($stmt->execute()) {
    echo "<script>alert('Meta cadastrada com sucesso!'); window.location.href='metas.php';</script>";
} else {
    echo "<script>alert('Erro ao cadastrar a meta.'); window.location.href='metas.php';</script>";
}

$stmt->close();
$conn->close();
?>
