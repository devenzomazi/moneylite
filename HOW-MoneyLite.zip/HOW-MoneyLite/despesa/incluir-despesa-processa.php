<?php
// Conectar ao banco
$conn = new mysqli("localhost", "root", "", "ua10"); // ajuste seu banco

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Receber os dados
$descricao = $_POST['descricao'];
$categoria = $_POST['categoria'];
$valor = $_POST['valor'];
$data_cadastro = $_POST['data_cadastro'];

// Inserir no banco
$sql = "INSERT INTO despesas (descricao, categoria, valor, data_cadastro) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssds", $descricao, $categoria, $valor, $data_cadastro);

if ($stmt->execute()) {
    echo "<script>alert('Despesa cadastrada com sucesso!'); window.location.href='despesa.php';</script>";
} else {
    echo "<script>alert('Erro ao cadastrar despesa.'); window.location.href='despesa.php';</script>";
}

$stmt->close();
$conn->close();
?>
