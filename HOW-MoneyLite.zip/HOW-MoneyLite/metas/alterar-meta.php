<?php
// Conectar ao banco
$conn = new mysqli("localhost", "root", "", "ua10");

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Pegar o ID da meta da URL
$id = intval($_GET['id']);

// Buscar a meta no banco
$sql = "SELECT * FROM metas WHERE id_meta = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$meta = $result->fetch_assoc();

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar Meta - MoneyLite</title>
</head>
<body>
    <h1>Alterar Meta</h1>

    <form method="POST" action="alterar-meta-processa.php">
        <input type="hidden" name="id" value="<?php echo $meta['id_meta']; ?>">

        <label for="descricao">Descrição da Meta:</label><br>
        <input type="text" name="descricao" id="descricao" value="<?php echo $meta['descricao']; ?>" required><br><br>

        <label for="valor_objetivo">Valor Objetivo:</label><br>
        <input type="number" step="0.01" name="valor_objetivo" id="valor_objetivo" value="<?php echo $meta['valor_objetivo']; ?>" required><br><br>

        <label for="valor_atual">Valor Atual:</label><br>
        <input type="number" step="0.01" name="valor_atual" id="valor_atual" value="<?php echo $meta['valor_atual']; ?>" required><br><br>

        <label for="data_limite">Data Limite:</label><br>
        <input type="date" name="data_limite" id="data_limite" value="<?php echo $meta['data_limite']; ?>" required><br><br>

        <button type="submit">Salvar Alterações</button>
        <button type="button" onclick="window.location.href='metas.php'">Cancelar</button>
    </form>
</body>
</html>
