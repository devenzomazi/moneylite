<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incluir Novo Ganho - MoneyLite</title>
</head>
<body>
    <h1>Incluir Novo Ganho</h1>

    <form method="POST" action="incluir-ganho-processa.php">
        Descrição: <input type="text" name="descricao" required><br><br>

        Categoria: <input type="text" name="categoria" required><br><br>

        Valor: <input type="number" step="0.01" name="valor" required><br><br>

        Data Cadastro: <input type="date" name="data_cadastro" required><br><br>

        <button type="submit">Salvar Ganho</button>
        <button type="button" onclick="window.location.href='ganhos.php'">Cancelar</button>
    </form>
</body>
</html>
