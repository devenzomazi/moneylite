<?php
// Conectar banco
$conn = new mysqli("localhost", "root", "", "ua10");

// Pegar ID da URL
$id = intval($_GET['id']);

// Buscar o ganho
$sql = "SELECT * FROM ganhos WHERE id_ganho = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$ganho = $result->fetch_assoc();

$stmt->close();
$conn->close();
?>

<!-- Mostrar formulário preenchido -->
<form method="POST" action="alterar-ganho-processa.php">
    <input type="hidden" name="id" value="<?php echo $ganho['id_ganho']; ?>">

    Descrição: <input type="text" name="descricao" value="<?php echo $ganho['descricao']; ?>"><br><br>

    Categoria: <input type="text" name="categoria" value="<?php echo $ganho['categoria']; ?>"><br><br>

    Valor: <input type="text" name="valor" value="<?php echo $ganho['valor']; ?>"><br><br>

    Data Cadastro: <input type="date" name="data_cadastro" value="<?php echo $ganho['data_cadastro']; ?>"><br><br>

    <button type="submit">Salvar Alterações</button>
</form>
