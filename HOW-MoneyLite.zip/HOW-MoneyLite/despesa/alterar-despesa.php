<?php
// Conectar ao banco
$conn = new mysqli("localhost", "root", "", "ua10"); // ajuste seu banco

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Pegar o ID da despesa
$id = intval($_GET['id']); // Proteção

// Buscar a despesa
$sql = "SELECT * FROM despesas WHERE id_despesa = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$despesa = $result->fetch_assoc();

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar Despesa - MoneyLite</title>
</head>
<body>
    <h1>Alterar Despesa</h1>

    <form method="POST" action="alterar-despesa-processa.php">
        <input type="hidden" name="id" value="<?php echo $despesa['id_despesa']; ?>">

        Descrição: <input type="text" name="descricao" value="<?php echo $despesa['descricao']; ?>" required><br><br>

        Categoria: <input type="text" name="categoria" value="<?php echo $despesa['categoria']; ?>" required><br><br>

        Valor: <input type="number" step="0.01" name="valor" value="<?php echo $despesa['valor']; ?>" required><br><br>

        Data Cadastro: <input type="date" name="data_cadastro" value="<?php echo $despesa['data_cadastro']; ?>" required><br><br>

        <button type="submit">Salvar Alterações</button>
        <button type="button" onclick="window.location.href='despesa.php'">Cancelar</button>
    </form>
</body>
</html>
