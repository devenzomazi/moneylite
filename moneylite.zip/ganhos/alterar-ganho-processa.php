<?php
// Conexão
include('../conexao.php');

// Receber dados
$id = intval($_POST['id']);
$descricao = $_POST['descricao'];
$categoria = $_POST['categoria'];
$valor = $_POST['valor'];
$data_cadastro = $_POST['data_cadastro'];

// Atualizar
$sql = "UPDATE ganhos SET descricao=?, categoria=?, valor=?, data_cadastro=? WHERE id_ganho=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssdsi", $descricao, $categoria, $valor, $data_cadastro, $id);

if ($stmt->execute()) {
    echo "<script>alert('Ganho alterado com sucesso!'); window.location.href='ganhos.php';</script>";
} else {
    echo "<script>alert('Erro ao alterar ganho.'); window.location.href='ganhos.php';</script>";
}

$stmt->close();
$conn->close();
?>
